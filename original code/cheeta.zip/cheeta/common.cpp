#include "common.h"

Logger::Logger(const string& filename) {
    log_file.open(filename, ios::out | ios::binary);
    if (!log_file) {
        cerr << "Error opening log file: " << filename << endl;
    }
    log_file << "\xEF\xBB\xBF";
}

Logger::~Logger() {
    if (log_file.is_open()) {
        log_file.close();
    }
}

FastFileReader::FastFileReader(const char* filename)
    : data(nullptr), size(0), hFile(INVALID_HANDLE_VALUE), hMapping(NULL) {
    hFile = CreateFileA(filename, GENERIC_READ, FILE_SHARE_READ, NULL,
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        throw runtime_error("Failed to open file: " + string(filename));
    }
    LARGE_INTEGER fileSize;
    if (!GetFileSizeEx(hFile, &fileSize)) {
        CloseHandle(hFile);
        throw runtime_error("Failed to get file size: " + string(filename));
    }
    size = static_cast<size_t>(fileSize.QuadPart);
    hMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
    if (hMapping == NULL) {
        CloseHandle(hFile);
        throw runtime_error("Failed to create file mapping: " + string(filename));
    }
    data = static_cast<char*>(MapViewOfFile(hMapping, FILE_MAP_READ, 0, 0, size));
    if (data == NULL) {
        CloseHandle(hMapping);
        CloseHandle(hFile);
        throw runtime_error("Failed to map view of file: " + string(filename));
    }
}
FastFileReader::~FastFileReader() {
    if (data) UnmapViewOfFile(data);
    if (hMapping) CloseHandle(hMapping);
    if (hFile != INVALID_HANDLE_VALUE) CloseHandle(hFile);
}
const char* FastFileReader::getData() const { return data; }
size_t FastFileReader::getSize() const { return size; }


void write_distribution_file(const string& filename,
    const vector<unsigned long long>& histogram,
    unsigned long long missing_count,
    unsigned long long total_pairs, Logger& logger) {
    ofstream fout(filename, ios::out | ios::binary);
    if (!fout) {
        logger << "Error opening distribution file: " << filename << endl;
        return;
    }
    fout << "\xEF\xBB\xBF";

    fout << "Start\tEnd\tCount\tFrequency\tCumulative" << endl;
    fout << fixed << setprecision(6);

    double freq = static_cast<double>(missing_count) / total_pairs;
    double cumulative = freq;
    fout << "MISSING\tMISSING\t" << missing_count << "\t"
        << freq << "\t" << cumulative << endl;

    for (int i = 0; i < NUM_BINS; i++) {
        double start = i * 0.001;
        double end = (i + 1) * 0.001;
        if (i == NUM_BINS - 1) end = 1.001; // Last bin includes 1.0

        freq = static_cast<double>(histogram[i]) / total_pairs;
        cumulative += freq;

        fout << start << "\t" << end << "\t"
            << histogram[i] << "\t"
            << freq << "\t" << cumulative << endl;
    }
    fout.close();
}

bool createDirectory(const string& path, Logger& logger) {
    if (CreateDirectoryA(path.c_str(), NULL)) {
        return true;
    }
    DWORD err = GetLastError();
    if (err == ERROR_ALREADY_EXISTS) {
        logger << "Directory already exists: " << path << endl;
        return true;
    }
    logger << "Failed to create directory: " << path << " (Error: " << err << ")" << endl;
    return false;
}

bool checkGPUMemory(size_t required_mem, Logger& logger) {
    size_t free_mem, total_mem;
    cudaMemGetInfo(&free_mem, &total_mem);
    bool result = free_mem > required_mem * 1.2; // Need 20% extra margin
    if (!result) {
        logger << "Warning: Insufficient GPU memory! Required: "
            << (required_mem / (1024.0 * 1024.0 * 1024.0))
            << " GB, Available: " << (free_mem / (1024.0 * 1024.0 * 1024.0))
            << " GB" << endl;
    }
    return result;
}


