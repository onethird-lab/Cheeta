#include "common.h"

void FastFileReader::parseAndTransferToGPU(int& rows, int& cols, 
    unsigned char* gpu_buffer, size_t& bytes_per_row, cudaStream_t stream) {
    rows = 0;
    cols = 0;
    int temp_cols = 0;
    bool in_number = false;
    bool new_line = true;

    for (size_t i = 0; i < size; i++) {
        if (data[i] == '\n' || data[i] == '\r') {
            if (data[i] == '\n') {
                rows++;
                if (temp_cols > cols) cols = temp_cols;
                temp_cols = 0;
                new_line = true;
            }
            in_number = false;
        }
        else if (isspace(data[i])) {
            in_number = false;
        }
        else if (!in_number) {
            in_number = true;
            temp_cols++;
        }
    }

    if (size > 0 && data[size - 1] != '\n' && data[size - 1] != '\r') rows++;
    if (temp_cols > cols) cols = temp_cols;

    bytes_per_row = (cols + 3) / 4;

    vector<const char*> line_ptrs;
    const char* ptr = data;
    line_ptrs.push_back(ptr);

    for (size_t i = 0; i < size; i++) {
        if (data[i] == '\n') {
            if (i + 1 < size) {
                line_ptrs.push_back(data + i + 1);
            }
        }
        else if (data[i] == '\r' && (i + 1 >= size || data[i + 1] != '\n')) {
            if (i + 1 < size) {
                line_ptrs.push_back(data + i + 1);
            }
        }
    }

    const int num_chunks = (rows + CHUNK_SIZE - 1) / CHUNK_SIZE;
    vector<thread> threads;
    vector<vector<unsigned char>> host_buffers(num_chunks);
    vector<size_t> buffer_sizes(num_chunks, 0);

    for (int chunk = 0; chunk < num_chunks; chunk++) {
        int start_row = chunk * CHUNK_SIZE;
        int end_row = min(start_row + CHUNK_SIZE, rows);
        int chunk_rows = end_row - start_row;

        host_buffers[chunk].resize(chunk_rows * bytes_per_row);
        buffer_sizes[chunk] = chunk_rows * bytes_per_row;

        threads.emplace_back([&, start_row, end_row, chunk] {
            for (int r = start_row; r < end_row; r++) {
                const char* line_ptr = line_ptrs[r];
                const char* next_line_ptr = (r < rows - 1) ? line_ptrs[r + 1] : data + size;

                for (int c = 0; c < cols; c++) {
                    while (line_ptr < next_line_ptr && isspace(*line_ptr)) line_ptr++;
                    if (line_ptr >= next_line_ptr) break;

                    int geno = 0;
                    if (*line_ptr == '0') geno = GENO_AA;
                    else if (*line_ptr == '1') geno = GENO_AB;
                    else if (*line_ptr == '2') geno = GENO_BB;
                    else if (*line_ptr == '9') geno = GENO_MISSING;
                    else geno = GENO_MISSING;

                    while (line_ptr < next_line_ptr && !isspace(*line_ptr)) line_ptr++;

                    int byte_idx = c / 4;
                    int shift = (c % 4) * 2;
                    int buffer_index = (r - start_row) * bytes_per_row + byte_idx;
                    host_buffers[chunk][buffer_index] |= (geno & 0x3) << shift;
                }
            }
            });
    }

    for (auto& t : threads) {
        if (t.joinable()) t.join();
    }
    threads.clear();

    size_t gpu_offset = 0;
    for (int chunk = 0; chunk < num_chunks; chunk++) {
        if (buffer_sizes[chunk] > 0) {
            cudaError_t status;
            if (stream) {
                status = cudaMemcpyAsync(gpu_buffer + gpu_offset,
                    host_buffers[chunk].data(),
                    buffer_sizes[chunk],
                    cudaMemcpyHostToDevice,
                    stream);
            }
            else {
                status = cudaMemcpy(gpu_buffer + gpu_offset,
                    host_buffers[chunk].data(),
                    buffer_sizes[chunk],
                    cudaMemcpyHostToDevice);
            }

            if (status != cudaSuccess) {
                throw runtime_error("CUDA memory copy failed: " + string(cudaGetErrorString(status)));
            }

            gpu_offset += buffer_sizes[chunk];
        }
    }

    if (stream) {
        cudaStreamSynchronize(stream);
    }
}


static void encode_worker(const float* r2_data, unsigned long long start, unsigned long long end,
    vector<unsigned char>& output, unsigned long long& output_size) {
    output_size = (end - start) * 2;
    output.resize(output_size);

    for (unsigned long long i = start; i < end; i++) {
        float r2 = r2_data[i];
        unsigned short val;

        if (r2 == -1.0f) {
            val = 0xFFFF; // Missing value marker
        }
        else {
            val = static_cast<unsigned short>(r2 * 1000.0f + 0.5f);
            if (val > 1000) val = 1000;
        }

        output[(i - start) * 2] = val & 0xFF;
        output[(i - start) * 2 + 1] = (val >> 8) & 0xFF;
    }
}

static void parallel_encode_batch(const float* r2_data, unsigned long long n, ofstream& fout, Logger& logger) {
    const unsigned long long min_chunk_size = 1000000; // Minimum items per thread

    unsigned num_threads = thread::hardware_concurrency();
    num_threads = min<unsigned>(num_threads, 16); // Limit max threads

    if (n < min_chunk_size * num_threads) {
        num_threads = max<unsigned>(1, n / min_chunk_size);
    }

    if (num_threads <= 1) {
        vector<unsigned char> buffer(n * 2);
        for (unsigned long long i = 0; i < n; i++) {
            float r2 = r2_data[i];
            unsigned short val;
            if (r2 == -1.0f) {
                val = 0xFFFF;
            }
            else {
                val = static_cast<unsigned short>(r2 * 1000.0f + 0.5f);
                if (val > 1000) val = 1000;
            }
            buffer[i * 2] = val & 0xFF;
            buffer[i * 2 + 1] = (val >> 8) & 0xFF;
        }
        fout.write(reinterpret_cast<const char*>(buffer.data()), n * 2);
        return;
    }

    vector<thread> threads;
    vector<vector<unsigned char>> thread_buffers(num_threads);
    vector<unsigned long long> thread_sizes(num_threads, 0);

    const unsigned long long chunk_size = (n + num_threads - 1) / num_threads;

    for (unsigned t = 0; t < num_threads; t++) {
        unsigned long long start_idx = t * chunk_size;
        unsigned long long end_idx = min(start_idx + chunk_size, n);

        if (start_idx < n) {
            threads.emplace_back([=, &thread_buffers, &thread_sizes] {
                vector<unsigned char> buffer;
                unsigned long long size;
                encode_worker(r2_data, start_idx, end_idx, buffer, size);
                thread_buffers[t] = move(buffer);
                thread_sizes[t] = size;
                });
        }
    }

    for (auto& t : threads) {
        t.join();
    }

    for (unsigned t = 0; t < num_threads; t++) {
        if (thread_sizes[t] > 0) {
            fout.write(reinterpret_cast<const char*>(thread_buffers[t].data()), thread_sizes[t]);
        }
    }
}

