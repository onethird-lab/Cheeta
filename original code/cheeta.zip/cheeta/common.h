// common.h
#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifdef _WIN32
#include <windows.h>
#endif

#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <chrono>
#include <thread>
#include <mutex>
#include <queue>
#include <atomic>
#include <iomanip>
#include <algorithm>
#include <cctype>
#include <thrust/copy.h>
#include <thrust/device_ptr.h>
#include <thrust/execution_policy.h>
#include <thrust/functional.h>
#include <thrust/device_vector.h>
#include <thrust/iterator/counting_iterator.h>
#include <thrust/gather.h>
#include <thrust/transform.h>
#include <map>
#include <condition_variable>
#include <memory>
#include <ctime>

using namespace std;
using namespace std::chrono;

#define TOLERANCE 0.00000001f
#define GENO_MISSING 0x3
#define GENO_AA 0x0
#define GENO_AB 0x1
#define GENO_BB 0x2
#define NUM_BINS 1001
#define MAX_GRID_SIZE 2147483647
#define MAX_LINE_LENGTH 1000000
#define CHUNK_SIZE 1000
#define GPU_BLOCK_SIZE (100 * 1024 * 1024)

struct ResultRecord {
    int snp0;
    int snp1;
    float ld;//r2 or D'
};

class Logger {
private:
    ofstream log_file;
    mutex log_mutex;

public:
    Logger(const string& filename);
    ~Logger();

    template<typename T>
    Logger& operator<<(const T& message) {
        lock_guard<mutex> lock(log_mutex);
        cout << message;
        if (log_file.is_open()) {
            log_file << message;
            log_file.flush();
        }
        return *this;
    }

    Logger& operator<<(ostream& (*manip)(ostream&)) {
        lock_guard<mutex> lock(log_mutex);
        manip(cout);
        if (log_file.is_open()) {
            manip(log_file);
            log_file.flush();
        }
        return *this;
    }
};

class FastFileReader {
public:
    FastFileReader(const char* filename);
    ~FastFileReader();

    const char* getData() const;
    size_t getSize() const;
    void parseAndTransferToGPU(int& rows, int& cols, unsigned char* gpu_buffer,
        size_t& bytes_per_row, cudaStream_t stream = nullptr);

private:
    char* data;
    size_t size;
    HANDLE hFile;
    HANDLE hMapping;
};

void write_distribution_file(const string& filename,
    const vector<unsigned long long>& histogram,
    unsigned long long missing_count,
    unsigned long long total_pairs, Logger& logger);

void encode_worker(const float* dprime_data, unsigned long long start, unsigned long long end,
    vector<unsigned char>& output, unsigned long long& output_size);
void parallel_encode_batch(const float* r2_data, unsigned long long n,
    ofstream& fout, Logger& logger);

bool createDirectory(const string& path, Logger& logger);
bool checkGPUMemory(size_t required_mem, Logger& logger);
int run_interChromLDr2(int argc, char* argv[]);
int run_interChromLDdprime(int argc, char* argv[]);
