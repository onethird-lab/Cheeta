#include "common.h"

__constant__ int d_df_COLS0;//��ֹ�����ض�������

__device__ __inline__ int get_geno_r2(const unsigned char* data, int idx) {
    int byte_idx = idx >> 2;
    int shift = (idx & 0x3) << 1;
    return (data[byte_idx] >> shift) & 0x3;
}

static void encode_worker(const float* r2_data, unsigned long long start, unsigned long long end,
    vector<unsigned char>& output, unsigned long long& output_size) {
    output_size = (end - start) * 2;
    output.resize(output_size);

    for (unsigned long long i = start; i < end; i++) {
        float r2 = r2_data[i];
        unsigned short val;

        if (r2 == -1.0f) {
            val = 0xFFFF; // Missing value marker
        }
        else {
            val = static_cast<unsigned short>(r2 * 1000.0f + 0.5f);
            if (val > 1000) val = 1000;
        }

        output[(i - start) * 2] = val & 0xFF;
        output[(i - start) * 2 + 1] = (val >> 8) & 0xFF;
    }
static void parallel_encode_batch(const float* r2_data, unsigned long long n, ofstream& fout, Logger& logger) {
    const unsigned long long min_chunk_size = 1000000; // Minimum items per thread

    unsigned num_threads = thread::hardware_concurrency();
    num_threads = min<unsigned>(num_threads, 16); // Limit max threads

    if (n < min_chunk_size * num_threads) {
        num_threads = max<unsigned>(1, n / min_chunk_size);
    }

    if (num_threads <= 1) {
        vector<unsigned char> buffer(n * 2);
        for (unsigned long long i = 0; i < n; i++) {
            float r2 = r2_data[i];
            unsigned short val;
            if (r2 == -1.0f) {
                val = 0xFFFF;
            }
            else {
                val = static_cast<unsigned short>(r2 * 1000.0f + 0.5f);
                if (val > 1000) val = 1000;
            }
            buffer[i * 2] = val & 0xFF;
            buffer[i * 2 + 1] = (val >> 8) & 0xFF;
        }
        fout.write(reinterpret_cast<const char*>(buffer.data()), n * 2);
        return;
    }

    vector<thread> threads;
    vector<vector<unsigned char>> thread_buffers(num_threads);
    vector<unsigned long long> thread_sizes(num_threads, 0);

    const unsigned long long chunk_size = (n + num_threads - 1) / num_threads;

    for (unsigned t = 0; t < num_threads; t++) {
        unsigned long long start_idx = t * chunk_size;
        unsigned long long end_idx = min(start_idx + chunk_size, n);

        if (start_idx < n) {
            threads.emplace_back([=, &thread_buffers, &thread_sizes] {
                vector<unsigned char> buffer;
                unsigned long long size;
                encode_worker(r2_data, start_idx, end_idx, buffer, size);
                thread_buffers[t] = move(buffer);
                thread_sizes[t] = size;
                });
        }
    }

    for (auto& t : threads) {
        t.join();
    }

    for (unsigned t = 0; t < num_threads; t++) {
        if (thread_sizes[t] > 0) {
            fout.write(reinterpret_cast<const char*>(thread_buffers[t].data()), thread_sizes[t]);
        }
    }
}
// sourced from Haploview
__device__ float calculate_r2(const unsigned char* SNP1, const unsigned char* SNP2, int n) {
    int known[4] = { 0 };  // AA, AB, BA, BB
    int doublehet = 0;
    int valid_samples = 0;

    for (int i = 0; i < n; i++) {
        int g1 = get_geno_r2(SNP1, i);
        int g2 = get_geno_r2(SNP2, i);

        if (g1 == GENO_MISSING || g2 == GENO_MISSING) continue;

        valid_samples++;
        if (g1 == GENO_AB && g2 == GENO_AB) {
            doublehet++;
        }
        else {
            int idx = (g1 << 2) | g2;
            switch (idx) {
            case (GENO_AA << 2) | GENO_AA: known[0] += 2; break;
            case (GENO_AA << 2) | GENO_AB: known[0] += 1; known[1] += 1; break;
            case (GENO_AA << 2) | GENO_BB: known[1] += 2; break;
            case (GENO_AB << 2) | GENO_AA: known[0] += 1; known[2] += 1; break;
            case (GENO_AB << 2) | GENO_BB: known[1] += 1; known[3] += 1; break;
            case (GENO_BB << 2) | GENO_AA: known[2] += 2; break;
            case (GENO_BB << 2) | GENO_AB: known[2] += 1; known[3] += 1; break;
            case (GENO_BB << 2) | GENO_BB: known[3] += 2; break;
            }
        }
    }

    if (valid_samples == 0) return -1.0f;

    float probHaps[4] = {
        (known[0] + 0.1f) / (valid_samples * 2 + 0.4f),
        (known[1] + 0.1f) / (valid_samples * 2 + 0.4f),
        (known[2] + 0.1f) / (valid_samples * 2 + 0.4f),
        (known[3] + 0.1f) / (valid_samples * 2 + 0.4f)
    };

    float old_loglike = -1e9f;
    for (int iter = 0; iter < 20; iter++) {
        float numHaps[4] = { (float)known[0], (float)known[1], (float)known[2], (float)known[3] };

        if (doublehet > 0) {
            float p = probHaps[0] * probHaps[3] / (probHaps[0] * probHaps[3] + probHaps[1] * probHaps[2]);
            numHaps[0] += doublehet * p;
            numHaps[3] += doublehet * p;
            numHaps[1] += doublehet * (1 - p);
            numHaps[2] += doublehet * (1 - p);
        }

        float total = numHaps[0] + numHaps[1] + numHaps[2] + numHaps[3];
        probHaps[0] = numHaps[0] / total;
        probHaps[1] = numHaps[1] / total;
        probHaps[2] = numHaps[2] / total;
        probHaps[3] = numHaps[3] / total;

        float loglike = known[0] * logf(probHaps[0]) + known[1] * logf(probHaps[1]) +
            known[2] * logf(probHaps[2]) + known[3] * logf(probHaps[3]) +
            doublehet * logf(probHaps[0] * probHaps[3] + probHaps[1] * probHaps[2]);

        if (fabsf(loglike - old_loglike) < TOLERANCE) break;
        old_loglike = loglike;
    }

    float num = probHaps[0] * probHaps[3] - probHaps[1] * probHaps[2];
    float pA1 = probHaps[0] + probHaps[1];
    float pB1 = 1.0f - pA1;
    float pA2 = probHaps[0] + probHaps[2];
    float pB2 = 1.0f - pA2;

    float denom = pA1 * pB1 * pA2 * pB2;
    if (denom < 1e-8f) return 0.0f;  // Avoid division by zero

    return (num * num) / denom;
}

__global__ void compute_ld_kernel_r2(
    const unsigned char* gpu_df0,
    const unsigned char* gpu_df1,
    int df0_ROWS, int df1_ROWS,
    float* gpu_results,
    unsigned long long start_idx,
    unsigned long long batch_size,
    unsigned long long* d_histogram,
    unsigned long long* d_missing_count,
    size_t bytes_per_row)
{
    unsigned long long idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= batch_size) return;

    unsigned long long global_idx = start_idx + idx;
    unsigned long long row0 = global_idx / df1_ROWS;
    unsigned long long row1 = global_idx % df1_ROWS;
    float r2 = calculate_r2(
        gpu_df0 + row0 * bytes_per_row,
        gpu_df1 + row1 * bytes_per_row,
        d_df_COLS0);

    gpu_results[idx] = r2;

    if (d_histogram && d_missing_count) {
        if (r2 == -1.0f) {
            atomicAdd(d_missing_count, 1);
        }
        else {
            int bin_index = min(static_cast<int>(r2 * 1000.0f), NUM_BINS - 1);
            atomicAdd(&d_histogram[bin_index], 1);
        }
    }
}

__global__ void filter_kernel_r2(
    const float* results,
    const unsigned long long start_idx,
    int df1_rows,
    float r2_cut,
    unsigned long long batch_size,
    ResultRecord* filtered_output,
    int* count)
{
    unsigned long long idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= batch_size) return;

    float r2 = results[idx];
    if (r2 >= r2_cut && r2 != -1.0f) {
        unsigned long long global_idx = start_idx + idx;
        int row0 = global_idx / df1_rows;
        int row1 = global_idx % df1_rows;

        int pos = atomicAdd(count, 1);
        filtered_output[pos] = { row0, row1, r2};
    }
}

int run_interChromLDr2(int argc, char* argv[]) {
    int i = 0;
    const char* file0 = nullptr;
    const char* file1 = nullptr;
    const char* output = nullptr;
    string dist_file = "";
    bool do_distribution = false;
    int compute_threads_per_block = 256;
    int filter_threads_per_block = 256;
    float r2_cut = 0.8f;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-file0") == 0 && i + 1 < argc) file0 = argv[++i];
        else if (strcmp(argv[i], "-file1") == 0 && i + 1 < argc) file1 = argv[++i];
        else if (strcmp(argv[i], "-o") == 0 && i + 1 < argc) output = argv[++i];
        else if (strcmp(argv[i], "-threads") == 0 && i + 1 < argc) {
            compute_threads_per_block = atoi(argv[++i]);
            i--;
            filter_threads_per_block = atoi(argv[++i]);
        }
        else if (strcmp(argv[i], "-r2_cut") == 0 && i + 1 < argc) r2_cut = atof(argv[++i]);
        else if (strcmp(argv[i], "-distribution") == 0 && i + 1 < argc) {
            dist_file = argv[++i];
            do_distribution = true;
        }
        else {
            cerr << "Unknown option: " << argv[i] << endl;
            return 1;
        }
    }

    if (!file0 || !file1 || !output) {
        cerr << "Missing required arguments for interChromLDr2!" << endl;
        return 1;
    }

    string log_filename = string(output) + ".log";
    Logger logger(log_filename);

    std::time_t now = std::time(nullptr);
    std::tm local_time_info;
    localtime_s(&local_time_info, &now);
    std::tm* local_time = &local_time_info;
    const char* months[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                           "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

    logger << "cheeta version: 1.0" << endl;

    logger << "Program started at: "
        << months[local_time->tm_mon] << " "
        << std::setw(2) << std::setfill('0') << local_time->tm_mday << " "
        << local_time->tm_year + 1900 << " "
        << std::setw(2) << std::setfill('0') << local_time->tm_hour << ":"
        << std::setw(2) << std::setfill('0') << local_time->tm_min << ":"
        << std::setw(2) << std::setfill('0') << local_time->tm_sec
        << std::endl;
    logger << "Command line:";
    for (int i = 0; i < argc; i++) {
        logger << " " << argv[i];
    }
    logger << endl;

    bool output_all_binary = (r2_cut == 0.0f);
    logger << "Threads per block: " << compute_threads_per_block << endl;
    logger << "Using r2 cutoff: " << r2_cut << endl;
    logger << "Output mode: " << (output_all_binary ? "BINARY (multi-threaded encoding)" : "TEXT") << endl;
    logger << "Distribution statistics: " << (do_distribution ? "ENABLED" : "DISABLED") << endl;
    if (do_distribution) {
        logger << "Distribution file: " << dist_file << endl;
    }

    size_t free_mem, total_mem;
    cudaError_t cudaStatus = cudaMemGetInfo(&free_mem, &total_mem);
    if (cudaStatus != cudaSuccess) {
        logger << "Failed to get GPU memory info: " << cudaGetErrorString(cudaStatus) << endl;
        return 1;
    }
    double total_gpu_mem_gb = total_mem / (1024.0 * 1024.0 * 1024.0);
    logger << "Total GPU memory: " << total_gpu_mem_gb << " GB" << endl;

    auto start_read = high_resolution_clock::now();
    int df0_rows = 0, df0_cols = 0, df1_rows = 0, df1_cols = 0;
    size_t df0_bytes_per_row = 0, df1_bytes_per_row = 0;//�����ԭ����������
    unsigned char* d_df0 = nullptr, * d_df1 = nullptr;//�����ԭ����������
    cudaStream_t stream;
    cudaStatus = cudaStreamCreate(&stream);
    if (cudaStatus != cudaSuccess) {
        logger << "Failed to create CUDA stream: " << cudaGetErrorString(cudaStatus) << endl;
        return 1;
    }

    logger << "Reading and transferring file0: " << file0 << endl;
    try {
        FastFileReader reader0(file0);

        size_t file_size = reader0.getSize();
        size_t approx_rows = file_size / 100; // Estimate rows
        size_t max_compressed_size = approx_rows * (file_size / approx_rows + 3) / 4;

        cudaStatus = cudaMalloc(&d_df0, max_compressed_size);
        if (cudaStatus != cudaSuccess) {
            throw runtime_error("Failed to allocate GPU memory: " + string(cudaGetErrorString(cudaStatus)));
        }

        reader0.parseAndTransferToGPU(df0_rows, df0_cols, d_df0, df0_bytes_per_row, stream);
        logger << "File0: " << df0_rows << " rows, " << df0_cols << " cols" << endl;
    }
    catch (const exception& e) {
        logger << "Error processing file0: " << e.what() << endl;
        if (d_df0) cudaFree(d_df0);
        cudaStreamDestroy(stream);
        return 1;
    }

    logger << "Reading and transferring file1: " << file1 << endl;
    try {
        FastFileReader reader1(file1);

        size_t file_size = reader1.getSize();
        size_t approx_rows = file_size / 100; // Estimate rows
        size_t max_compressed_size = approx_rows * (file_size / approx_rows + 3) / 4;

        cudaStatus = cudaMalloc(&d_df1, max_compressed_size);
        if (cudaStatus != cudaSuccess) {
            throw runtime_error("Failed to allocate GPU memory: " + string(cudaGetErrorString(cudaStatus)));
        }

        reader1.parseAndTransferToGPU(df1_rows, df1_cols, d_df1, df1_bytes_per_row, stream);
        logger << "File1: " << df1_rows << " rows, " << df1_cols << " cols" << endl;
    }
    catch (const exception& e) {
        logger << "Error processing file1: " << e.what() << endl;
        if (d_df0) cudaFree(d_df0);
        if (d_df1) cudaFree(d_df1);
        cudaStreamDestroy(stream);
        return 1;
    }

    if (df0_cols != df1_cols) {
        logger << "Error: Columns of two files must be the same!" << endl;
        if (d_df0) cudaFree(d_df0);
        if (d_df1) cudaFree(d_df1);
        cudaStreamDestroy(stream);
        return 1;
    }

    cudaStatus = cudaMemcpyToSymbol(d_df_COLS0, &df0_cols, sizeof(int));
    if (cudaStatus != cudaSuccess) {
        logger << "cudaMemcpyToSymbol failed: " << cudaGetErrorString(cudaStatus) << endl;
        if (d_df0) cudaFree(d_df0);
        if (d_df1) cudaFree(d_df1);
        cudaStreamDestroy(stream);
        return 1;
    }

    auto end_read = high_resolution_clock::now();
    double read_time = duration_cast<milliseconds>(end_read - start_read).count() / 1000.0;
    logger << "Data loaded and transferred to GPU in " << read_time << " seconds" << endl;

    unsigned long long total_pairs = (unsigned long long)df0_rows * df1_rows;
    size_t result_data_mem = total_pairs * sizeof(float);

    double result_data_gb = result_data_mem / (1024.0 * 1024.0 * 1024.0);
    double required_mem_gb = (df0_rows * df0_bytes_per_row + df1_rows * df1_bytes_per_row + result_data_mem)
        / (1024.0 * 1024.0 * 1024.0);

    logger << "Result data size: " << result_data_gb << " GB" << endl;
    logger << "Total required GPU memory: " << required_mem_gb << " GB" << endl;
    logger << "Total SNP pairs to calculate: " << total_pairs << endl;

    unsigned long long* d_histogram = nullptr;
    unsigned long long* d_missing_count = nullptr;
    vector<unsigned long long> histogram(NUM_BINS, 0);
    unsigned long long missing_count = 0;

    if (do_distribution) {
        cudaStatus = cudaMalloc(&d_histogram, NUM_BINS * sizeof(unsigned long long));
        if (cudaStatus != cudaSuccess) {
            logger << "Failed to allocate histogram memory: " << cudaGetErrorString(cudaStatus) << endl;
            cudaFree(d_df0);
            cudaFree(d_df1);
            cudaStreamDestroy(stream);
            return 1;
        }

        cudaStatus = cudaMalloc(&d_missing_count, sizeof(unsigned long long));
        if (cudaStatus != cudaSuccess) {
            logger << "Failed to allocate missing count memory: " << cudaGetErrorString(cudaStatus) << endl;
            cudaFree(d_histogram);
            cudaFree(d_df0);
            cudaFree(d_df1);
            cudaStreamDestroy(stream);
            return 1;
        }

        cudaMemset(d_histogram, 0, NUM_BINS * sizeof(unsigned long long));
        cudaMemset(d_missing_count, 0, sizeof(unsigned long long));
    }

    size_t free_mem_after, total_mem_after;
    cudaStatus = cudaMemGetInfo(&free_mem_after, &total_mem_after);
    if (cudaStatus != cudaSuccess) {
        logger << "Failed to get GPU memory info: " << cudaGetErrorString(cudaStatus) << endl;
        if (d_histogram) cudaFree(d_histogram);
        if (d_missing_count) cudaFree(d_missing_count);
        cudaFree(d_df0);
        cudaFree(d_df1);
        cudaStreamDestroy(stream);
        return 1;
    }

    size_t available_mem = static_cast<size_t>(free_mem_after * 0.7); // Use 70% of available memory

    size_t per_batch_item_mem = sizeof(float);
    if (!output_all_binary) {
        per_batch_item_mem += sizeof(ResultRecord); // Filtered records
    }

    size_t max_batch_items = available_mem / per_batch_item_mem;

    max_batch_items = (max_batch_items / compute_threads_per_block) * compute_threads_per_block;

    logger << "Max batch items: " << max_batch_items
        << " (" << (max_batch_items * per_batch_item_mem / (1024.0 * 1024.0 * 1024.0)) << " GB)"
        << endl;

    float* device_results = nullptr;
    cudaStatus = cudaMalloc(&device_results, max_batch_items * sizeof(float));
    if (cudaStatus != cudaSuccess) {
        logger << "cudaMalloc device_results failed: " << cudaGetErrorString(cudaStatus) << endl;
        if (d_histogram) cudaFree(d_histogram);
        if (d_missing_count) cudaFree(d_missing_count);
        cudaFree(d_df0);
        cudaFree(d_df1);
        cudaStreamDestroy(stream);
        return 1;
    }

    ResultRecord* d_filtered_records = nullptr;
    int* d_count = nullptr;

    if (!output_all_binary) {
        cudaStatus = cudaMalloc(&d_filtered_records, max_batch_items * sizeof(ResultRecord));
        if (cudaStatus != cudaSuccess) {
            logger << "cudaMalloc d_filtered_records failed: " << cudaGetErrorString(cudaStatus) << endl;
            cudaFree(device_results);
            if (d_histogram) cudaFree(d_histogram);
            if (d_missing_count) cudaFree(d_missing_count);
            cudaFree(d_df0);
            cudaFree(d_df1);
            cudaStreamDestroy(stream);
            return 1;
        }

        cudaStatus = cudaMalloc(&d_count, sizeof(int));
        if (cudaStatus != cudaSuccess) {
            logger << "cudaMalloc d_count failed: " << cudaGetErrorString(cudaStatus) << endl;
            cudaFree(device_results);
            cudaFree(d_filtered_records);
            if (d_histogram) cudaFree(d_histogram);
            if (d_missing_count) cudaFree(d_missing_count);
            cudaFree(d_df0);
            cudaFree(d_df1);
            cudaStreamDestroy(stream);
            return 1;
        }
    }

    string output_dir;
    if (output_all_binary) {
        output_dir = string(output) + "_parts";
        if (!createDirectory(output_dir, logger)) {
            if (d_histogram) cudaFree(d_histogram);
            if (d_missing_count) cudaFree(d_missing_count);
            cudaFree(device_results);
            if (d_filtered_records) cudaFree(d_filtered_records);
            if (d_count) cudaFree(d_count);
            cudaFree(d_df0);
            cudaFree(d_df1);
            cudaStreamDestroy(stream);
            return 1;
        }
        logger << "Creating output directory: " << output_dir << endl;
    }

    ofstream fout_txt;
    vector<float> host_results; // For binary mode

    if (output_all_binary) {
        host_results.resize(max_batch_items);
    }
    else {
        fout_txt.open(output, ios::out | ios::binary);
        if (!fout_txt) {
            logger << "Error opening text output file!" << endl;
            if (d_histogram) cudaFree(d_histogram);
            if (d_missing_count) cudaFree(d_missing_count);
            cudaFree(device_results);
            if (d_filtered_records) cudaFree(d_filtered_records);
            if (d_count) cudaFree(d_count);
            cudaFree(d_df0);
            cudaFree(d_df1);
            cudaStreamDestroy(stream);
            return 1;
        }
        fout_txt << "\xEF\xBB\xBF";
        fout_txt << "SNP0\tSNP1\tr2" << endl;
        fout_txt << fixed << setprecision(6);
    }

    unsigned long long total_filtered = 0;
    auto start_compute = high_resolution_clock::now();
    unsigned long long processed = 0;
    int batch_num = 0;
    const unsigned long long MAX_RESULTS_PER_FILE = 1000000; // 100M results per file
    int part_counter = 0; 

    while (processed < total_pairs) {
        auto start_calc = high_resolution_clock::now();
        unsigned long long current_batch = min(static_cast<unsigned long long>(max_batch_items), total_pairs - processed);

        unsigned long long grid_size = (current_batch + compute_threads_per_block - 1) / compute_threads_per_block;
        if (grid_size > MAX_GRID_SIZE) {
            current_batch = MAX_GRID_SIZE * compute_threads_per_block;
            grid_size = MAX_GRID_SIZE;
        }

        int grid_dim = static_cast<int>(grid_size);

        compute_ld_kernel_r2 << <grid_dim, compute_threads_per_block, 0, stream >> > (
            d_df0, d_df1, df0_rows, df1_rows,
            device_results, processed, current_batch,
            d_histogram, d_missing_count, df0_bytes_per_row);

        cudaStatus = cudaGetLastError();
        if (cudaStatus != cudaSuccess) {
            logger << "Kernel launch failed: " << cudaGetErrorString(cudaStatus) << endl;
            break;
        }
        cudaStreamSynchronize(stream);

        auto end_calc = high_resolution_clock::now();
        batch_num++;
        logger << "Batch " << batch_num << ": " << current_batch << " pairs ("
            << duration_cast<milliseconds>(end_calc - start_calc).count()
            << " ms)" << endl;

        if (output_all_binary) {
            auto start_copy = high_resolution_clock::now();
            cudaMemcpyAsync(host_results.data(), device_results, current_batch * sizeof(float), cudaMemcpyDeviceToHost, stream);
            cudaStreamSynchronize(stream);//��ԭ������ȣ����������

            unsigned long long remaining = current_batch;
            unsigned long long offset = 0;

            while (remaining > 0) {
                unsigned long long chunk_size = min(remaining, MAX_RESULTS_PER_FILE);
                string part_filename = output_dir + "\\part_" + to_string(part_counter++) + ".bin";

                ofstream fout_part(part_filename, ios::binary);
                if (!fout_part) {
                    logger << "Error opening part file: " << part_filename << endl;
                    break;
                }

                unsigned long long start_pos = processed + offset;
                fout_part.write(reinterpret_cast<const char*>(&start_pos), sizeof(start_pos));
                fout_part.write(reinterpret_cast<const char*>(&chunk_size), sizeof(chunk_size));

                parallel_encode_batch(host_results.data() + offset, chunk_size, fout_part, logger);
                fout_part.close();

                offset += chunk_size;
                remaining -= chunk_size;

                logger << "  Created part: " << part_filename << " (" << chunk_size << " pairs)" << endl;
            }

            auto end_copy = high_resolution_clock::now();
            logger << "  Copy & Encode: "
                << duration_cast<milliseconds>(end_copy - start_copy).count()
                << " ms" << endl;
        }
        else {
            auto start_filter = high_resolution_clock::now();
            cudaMemsetAsync(d_count, 0, sizeof(int), stream);

            unsigned long long filter_grid_size = (current_batch + filter_threads_per_block - 1) / filter_threads_per_block;
            int filter_grid_dim = static_cast<int>(min<unsigned long long>(filter_grid_size, MAX_GRID_SIZE));

            filter_kernel_r2 << <filter_grid_dim, filter_threads_per_block, 0, stream >> > (
                device_results,
                processed,
                df1_rows,
                r2_cut,
                current_batch,
                d_filtered_records,
                d_count);

            cudaStreamSynchronize(stream);
            cudaStatus = cudaGetLastError();
            if (cudaStatus != cudaSuccess) {
                logger << "CUDA error during filtering: " << cudaGetErrorString(cudaStatus) << endl;
                break;
            }

            int filtered_count;
            cudaMemcpyAsync(&filtered_count, d_count, sizeof(int), cudaMemcpyDeviceToHost, stream);
            cudaStreamSynchronize(stream);
            total_filtered += filtered_count;

            auto end_filter = high_resolution_clock::now();
            logger << "  Filtering: " << filtered_count << " records ("
                << duration_cast<milliseconds>(end_filter - start_filter).count()
                << " ms)" << endl;

            auto start_copy = high_resolution_clock::now();
            vector<ResultRecord> host_records(filtered_count);
            if (filtered_count > 0) {
                cudaMemcpyAsync(host_records.data(), d_filtered_records,
                    filtered_count * sizeof(ResultRecord), cudaMemcpyDeviceToHost, stream);
                cudaStreamSynchronize(stream);
            }
            auto end_copy = high_resolution_clock::now();
            logger << "  Copy: " << duration_cast<milliseconds>(end_copy - start_copy).count()
                << " ms" << endl;

            sort(host_records.begin(), host_records.end(), [](const ResultRecord& a, const ResultRecord& b) {
                if (a.snp0 != b.snp0) {
                    return a.snp0 < b.snp0;
                }
                return a.snp1 < b.snp1;
                });

            for (int i = 0; i < filtered_count; i++) {
                fout_txt << host_records[i].snp0 << "\t"
                    << host_records[i].snp1 << "\t"
                    << host_records[i].ld << "\n";
            }
        }

        processed += current_batch;
        double progress = 100.0 * processed / total_pairs;
        logger << "  Progress: " << fixed << setprecision(2) << progress << "%" << endl;
    }

    auto end_compute = high_resolution_clock::now();
    double compute_time = duration_cast<milliseconds>(end_compute - start_compute).count() / 1000.0;
    logger << "Computation time: " << compute_time << " seconds" << endl;

    if (!output_all_binary) {
        logger << "Total filtered records: " << total_filtered << endl;
    }

    if (do_distribution) {
        auto start_dist = high_resolution_clock::now();

        cudaMemcpyAsync(histogram.data(), d_histogram,
            NUM_BINS * sizeof(unsigned long long), cudaMemcpyDeviceToHost, stream);
        cudaMemcpyAsync(&missing_count, d_missing_count,
            sizeof(unsigned long long), cudaMemcpyDeviceToHost, stream);
        cudaStreamSynchronize(stream);

        unsigned long long total_histogram = missing_count;
        for (int i = 0; i < NUM_BINS; i++) {
            total_histogram += histogram[i];
        }
        logger << "Distribution stats: " << total_histogram << " pairs ("
            << 100.0 * total_histogram / total_pairs << "% of total)" << endl;

        write_distribution_file(dist_file, histogram, missing_count, total_pairs, logger);

        auto end_dist = high_resolution_clock::now();
        logger << "Distribution saved to: " << dist_file << " ("
            << duration_cast<milliseconds>(end_dist - start_dist).count()
            << " ms)" << endl;
    }

    if (output_all_binary) {
        string meta_filename = string(output) + ".meta";
        ofstream meta_file(meta_filename, ios::out | ios::binary);
        
        if (meta_file) {
            // Write UTF-8 BOM for Chinese characters
            meta_file << "\xEF\xBB\xBF";
            meta_file << df0_rows << endl;
            meta_file << df1_rows << endl;
            meta_file << output_dir << endl;
            logger << "Metadata saved to: " << meta_filename << endl;
        }
        else {
            logger << "Failed to create metadata file: " << meta_filename << endl;
        }
    }

    cudaFree(device_results);
    if (!output_all_binary) {
        cudaFree(d_filtered_records);
        cudaFree(d_count);
    }
    cudaFree(d_df0);
    cudaFree(d_df1);

    if (d_histogram) cudaFree(d_histogram);
    if (d_missing_count) cudaFree(d_missing_count);

    cudaStreamDestroy(stream);

    if (!output_all_binary) {
        fout_txt.close();
    }

    std::time_t now_end = std::time(nullptr);
    std::tm local_time_info2;
    localtime_s(&local_time_info2, &now_end);
    std::tm* local_time_end = &local_time_info2;

    logger << "Program finished successfully at: "
        << months[local_time_end->tm_mon] << " "
        << std::setw(2) << std::setfill('0') << local_time_end->tm_mday << " "
        << local_time_end->tm_year + 1900 << " "
        << std::setw(2) << std::setfill('0') << local_time_end->tm_hour << ":"
        << std::setw(2) << std::setfill('0') << local_time_end->tm_min << ":"
        << std::setw(2) << std::setfill('0') << local_time_end->tm_sec
        << std::endl;

    return 0;
}
