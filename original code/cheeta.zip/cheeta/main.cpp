#include "common.h"

void show_help() {
    cout << "cheeta version: 1.0" << endl;
    cout << "Usage: cheeta <command> [options]" << endl;
    cout << "Commands:" << endl;
    cout << "  interChromLDr2    Calculate cross-chromosome LD" << endl;
    cout << endl;
    cout << "Example for interChromLDr2:" << endl;
    cout << "cheeta interChromLDr2 -file0 file0.txt -file1 file1.txt -o output.txt "
        << "[-threads threads_per_block] "
        << "[-r2_cut cutoff] [-distribution dist_file]" << endl;
    cout << endl;
    cout << "cheeta interChromLDdprime -file0 file0.txt -file1 file1.txt -o output.txt "
        << "[-threads threads_per_block] "
        << "[-dprime_cut cutoff] [-distribution dist_file]" << endl;

}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        show_help();
        return 1;
    }

    string command = argv[1];

    int new_argc = argc - 1;
    char** new_argv = argv + 1;

    if (command == "interChromLDr2") {
        return run_interChromLDr2(new_argc, new_argv);
    }
    if (command == "interChromLDdprime") {
        return run_interChromLDdprime(new_argc, new_argv);
    }
    else {
        cerr << "Unknown command: " << command << endl;
        show_help();
        return 1;
    }
}